#ifndef COMMENT_H
#define COMMENT_H
#include <stdio.h>
#include <string.h>
struct QMSG
{
    char buf[1022];
    short type;
};

struct register_node
{
    register_node(const char * name , const char * password ) {
        strcpy(this->name,name);
        strcpy(this->password,password);
    }
    char name[128];
    char password[128];
};
class comment
{
public:
    comment();

};

#endif // COMMENT_H
