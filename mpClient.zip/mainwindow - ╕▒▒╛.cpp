#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "test.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_isDragging(false) // 初始化为 false 表示没有在拖拽

{
    ui->setupUi(this);
    //    QPixmap qmap(":/new/prefix1/孤独摇滚！.png");
    //    ui->label->setPixmap(qmap);
    //    ui->label->setScaledContents(true);//设置自动缩放

    ui->label->setStyleSheet("border-image:url(:/昏 睡 虎 鲸.jpg);border: 1px solid black;border-radius:35px;");
    ui->pushButton_3->setStyleSheet("border-image: url(:/关闭 (2).png); border:7px solid black; border-radius: 16px; ");

    pMusic = new music;


    QFile file(":/style.qss");//构建一个QFILE对象
    file.open(QIODevice::ReadOnly);//打开构造函数中指定的文件

    QTextStream in(&file);//创建一个文本流，参数为打开的文件
    in.setCodec("UTF-8");//设置读取编码为GBK的文件
    QString qs = in.readAll();//读取所有的文件内容
    file.close();
    this->setStyleSheet(qs);
    this->setWindowFlag(Qt::FramelessWindowHint);//把主窗口边框去掉
    this->setAttribute(Qt::WA_TranslucentBackground);//把窗口设置为透明


    //-------------------------------------------客户端----------------------------------------------------
    // 创建客户端对象
    clientSocket = new QTcpSocket(this);

    // 尝试连接到服务器
    clientSocket->connectToHost("172.30.224.85", 9000);
    if (clientSocket->waitForConnected(3000)) {  // 等待最多 3 秒
        qDebug() << "客户端成功连接到服务器";
    } else {
        qDebug() << "客户端连接服务器失败：" << clientSocket->errorString();//错误处理
    }
    // 连接信号
    connect(clientSocket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    //readyRead是有消息可读的信号
    connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
    qDebug()<<"666666666666666666666666"<<endl;

    pForm1 = new registerForm(this, clientSocket);
    connect(pForm1,SIGNAL(back()),this,SLOT(on_back()));




}




void MainWindow::on_back()
{
    this->show();
}

void MainWindow::onConnected() {

    qDebug()<<"连接成功了"<<endl;

}

void MainWindow::onReadyRead()
{
    char buf[128];
    qint64 ret = clientSocket->read(buf,128);
    qDebug()<<ret<<" "<<buf<<endl;
    if(strcmp(buf,"right")==0)
    {
        this->hide();
        pMusic->show();
    }
}

void MainWindow::on_pushButton_clicked()
{
    this->hide();

    pForm1->show();
    qDebug() << "111" << endl;
}

void MainWindow::on_pushButton_3_clicked()
{
    close();
}


void MainWindow::on_pushButton_2_clicked()
{
    qDebug() << "777777777777777777777" << endl;
    QMSG msg;
    msg.type = 2;//登陆
    QString str = ui->LineEdit->text();
    std::string str1 = str.toStdString();

    QString str_psw = ui->LineEdit_2->text();
    std::string str_psw1 = str_psw.toStdString();

    register_node rn(str1.c_str(),str_psw1.c_str());
    memcpy(msg.buf,&rn,sizeof (rn));

    clientSocket->write((char *)&msg,sizeof (msg));

    clientSocket->read((char*)&msg,sizeof(msg));//读取反过来的所有数据
    if(strcmp(msg.buf,"right"))
    {
        this->hide();
        pMusic->show();
    }
    else
    {
        qDebug() << "密码错误" << endl;
    }


}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    // 当鼠标左键按下时，开始记录位置
    if(event->button() == Qt::LeftButton) {
        m_isDragging = true;
        m_startPoint = event->globalPos();  // 记录鼠标按下时的全局位置
        m_windowPoint = this->frameGeometry().topLeft();  // 记录窗口左上角的位置
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    // 如果正在拖拽窗口
    if(m_isDragging) {
        QPoint movePoint = event->globalPos() - m_startPoint;  // 计算移动的距离
        this->move(m_windowPoint + movePoint);  // 更新窗口位置
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    // 当鼠标释放时，停止拖拽
    if(event->button() == Qt::LeftButton) {
        m_isDragging = false;
    }
}
