#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QMainWindow>
#include <QDebug>
#include <QMouseEvent>
#include <QCryptographicHash>
#include <QTcpServer>
#include <QTcpSocket>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "registerform.h"
#include "comment.h"
#include <QPainter>
#include "music.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QPaintEvent>
#include "qtmaterialdrawer.h"
#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);


    void setupDrawer();
public slots:
    void on_back();
    void login_auto();
    void showThisWindow();
private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();



    void on_pushButton_2_clicked();


    void onConnected();
    void onReadyRead();
private:
    Ui::MainWindow *ui;
    QList<QPoint> pointList;//用来存放点的LIST

    bool m_isDragging;     // 判断是否正在拖拽窗口
    QPoint m_startPoint;   // 鼠标按下时的坐标
    QPoint m_windowPoint;  // 鼠标按下时窗口左上角的坐标
    registerForm *pForm1;
    QTcpSocket *clientSocket;
    music *pMusic;


};
#endif // MAINWINDOW_H
