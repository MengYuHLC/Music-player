#ifndef MUSIC_H
#define MUSIC_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QStandardItemModel>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMouseEvent>
#include "qtmaterialdrawer.h"
#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QTimer>
#include "test.h"


namespace Ui {
class music;
}

struct song
{
    QString songname;   //歌曲名
    QString singer;     //歌手
    QString album_name; //专辑
    int duration2;      //时间
    int music_id;       //音乐id
};
class music : public QMainWindow
{
    Q_OBJECT

public:
    music(QWidget *parent = nullptr);
    ~music();

    void parseJson(QByteArray data);
    void setupDrawer();

    void music_lic();
public slots:
    void replyFinished(QNetworkReply * reply);
    void slot_durationChanged(qint64 duration);
    void slot_positionChanged(qint64 position);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);

    void on_horizontalSlider_sliderReleased();

    void getMusicLrc(QByteArray data);
    void updateLyrics();
private slots:
    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_doubleClicked(const QModelIndex &index);

    void on_pushButton_3_clicked();




signals:
    void search();
    void lrc();

private:
    Ui::music *ui;
    QNetworkAccessManager *manage;
    QList<song> song_List;
    QList<song> song_love;
    QStringList songList;
    QStandardItemModel * pModel;
    QStringList titles;
    QMediaPlaylist * playlist;
    QMediaPlayer * player;

    QList<QPoint> pointList;//用来存放点的LIST

    bool m_isDragging;     // 判断是否正在拖拽窗口
    QPoint m_startPoint;   // 鼠标按下时的坐标
    QPoint m_windowPoint;  // 鼠标按下时窗口左上角的坐标
    QMediaPlaylist *newPlaylist;
    int newSearchStartIndex;
    int size;


    int love_index = 0;
    int currentIndex;
    int currentSongId;//当前歌曲id
    QString currentSongName;//当前歌曲名
    QString currentSinger;     //歌手
    QString currentAlbum_name; //专辑
    int currentDuration2;

    QMap<qint64, QString> lrcMap; // 用于存储时间戳和歌词的映射
};

#endif // MUSIC_H
