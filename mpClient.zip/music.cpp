#include "music.h"
#include "ui_music.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QLineEdit>
#include "customdelegete.h"


music::music(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::music)
{
    ui->setupUi(this);
    ui->tableView->horizontalHeader()->setStyleSheet("QHeaderView::section { background: transparent; };");
    ui->pushButton->setStyleSheet("border-image:url(:/播放 (1).png);border: 1px solid black;border-radius:20px;");
    ui->pushButton_2->setStyleSheet("border-image:url(:/搜索.png);border: 1px solid black;border-radius:15px;");
    ui->pushButton_3->setStyleSheet("border-image: url(:/关闭 (2).png); border:7px solid black; border-radius: 16px; ");
    ui->label->setText(0);
    ui->label_2->setText(0);
    ui->label_4->setStyleSheet("background-color: rgba(0, 0, 0, 50%); color: #e9dcff;");
    ui->pushButton_4->setStyleSheet("border-image: url(:/返回.png); border:7px solid black; border-radius: 16px; ");
    ui->label_4->setWordWrap(true);//允许自动换行
    ui->label_4->setVisible(true);


    QTimer *lyricsTimer = new QTimer(this);
    connect(lyricsTimer, &QTimer::timeout, this, &music::updateLyrics);
    lyricsTimer->start(100); // 每100毫秒更新一次

    //    setupDrawer();
    //    ui->tableView->setStyleSheet(
    //        "QTableView::item:selected {"
    //        "   background-color: transparent;"  // 设置选中时的背景色为透明
    //        "}"
    //        "QTableView::item {"
    //        "   background-color: transparent;"  // 设置未选中时的背景色
    //        "}"
    //    );





    QFile file(":/music.qss");//构建一个QFILE对象
    file.open(QIODevice::ReadOnly);//打开构造函数中指定的文件

    QTextStream in(&file);//创建一个文本流，参数为打开的文件
    in.setCodec("UTF-8");//设置读取编码为GBK的文件
    QString qs = in.readAll();//读取所有的文件内容
    file.close();
    this->setStyleSheet(qs);
    this->setWindowFlag(Qt::FramelessWindowHint);//把主窗口边框去掉
    this->setAttribute(Qt::WA_TranslucentBackground);//把窗口设置为透明
    manage = new QNetworkAccessManager;
    connect(manage, SIGNAL(finished(QNetworkReply*)),
            this, SLOT(replyFinished(QNetworkReply*)));
    pModel = new QStandardItemModel(ui->tableView);//实例化模型，并且指定模型依赖的控件
    ui->tableView->setModel(pModel);
    ui->tableView->setItemDelegateForColumn(4,new customDelegete);
    //    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//布局排版是全部伸展开的效果
    ui->tableView->resizeColumnsToContents();
    //    ui->pushButton->setStyleSheet("border:7px solid black; border-radius: 16px;");

    titles << "歌名" << "歌手" << "专辑" << "时长" <<"收藏";

    playlist = new QMediaPlaylist;

    player = new QMediaPlayer;
    player->setPlaylist(playlist);

    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(slot_positionChanged(qint64)));
    connect(player,SIGNAL(durationChanged(qint64)),this,SLOT(slot_durationChanged(qint64)));
    //    connect(ui->horizontalSlider, SIGNAL(sliderReleased()), this, SLOT(on_horizontalSlider_valueChanged(int)));
    connect(ui->horizontalSlider, SIGNAL(sliderReleased()), this, SLOT(on_horizontalSlider_sliderReleased()));


}


void music::updateLyrics()
{
    qint64 position = player->position()/1000; // 当前播放位置（秒）
    if (lrcMap.isEmpty()) {
        ui->label_4->setText("----");
        return;
    }

    // 查找与当前播放位置相匹配的歌词
    auto it = lrcMap.upperBound(position);

    // 调试输出


//    for (auto it = lrcMap.constBegin(); it != lrcMap.constEnd(); ++it) {
//        qDebug() << "当前播放位置（秒）:" << position;
//        qDebug() << "时间戳:" << it.key() << "歌词:" << it.value();
//    }
    if (it == lrcMap.begin()) {
        ui->label_4->setText(QString("%1").arg(currentSongName));
    } else {
        --it;
        ui->label_4->setText(it.value());
    }
}


void music::replyFinished(QNetworkReply* reply)
{
    qDebug() << "网页已响应" << endl;
    QVariant ret = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    qDebug()<<"网页返回状态为"<<ret<<endl;
    QByteArray data = reply->readAll(); // 读取所有的网络数据
    QString url = reply->url().toString();

    qDebug() << url << endl;
    if (ret == 200)
    {
        if (url.contains("lyric"))
        {
            getMusicLrc(data);// 处理歌词


        } else
        {
            parseJson(data); // 解析音乐列表
        }
    }


}

void music::on_horizontalSlider_sliderReleased()
{
    int value = ui->horizontalSlider->value(); // 获取滑块的当前值
    qint64 duration = player->duration(); // 获取总时长
    qint64 position = (duration * value) / ui->horizontalSlider->maximum(); // 计算播放位置
    player->setPosition(position); // 更新播放位置
}




void music::parseJson(QByteArray data)
{
    QString songname_original2; //歌曲名
    QString singername2;        //歌手
    QString album_name2;        //专辑
    int duration2;          	//时间
    int music_id;               //音乐id
    QJsonParseError json_error;//JSON解析错误对象

    QJsonDocument parse_doucment = QJsonDocument::fromJson(data, &json_error);
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            QJsonObject json_object = parse_doucment.object();
            if(json_object.contains("result"))
            {
                QJsonValue json_value = json_object.value("result");
                if(json_value.isObject())
                {
                    QJsonObject json_object_2 = json_value.toObject();
                    if(json_object_2.contains("songs"))
                    {
                        QJsonValue json_value_2 = json_object_2.value("songs");
                        if(json_value_2.isArray())
                        {
                            QJsonArray json_array = json_value_2.toArray();
                            int size = json_array.size();
                            for(int i = 0;i < size; i++)
                            {
                                QJsonValue json_value_3 = json_array.at(i);
                                if(json_value_3.isObject())
                                {
                                    QJsonObject json_object_3 = json_value_3.toObject();
                                    if(json_object_3.contains("album"))
                                    {
                                        QJsonValue json_value_4 = json_object_3.value("album");
                                        if(json_value_4.isObject())
                                        {
                                            QJsonObject json_object_4 = json_value_4.toObject();
                                            if(json_object_4.contains("name"))
                                            {
                                                QJsonValue json_value_5 = json_object_4.value("name");
                                                if(json_value_5.isString())
                                                {
                                                    album_name2 = json_value_5.toString();
                                                }

                                            }
                                        }
                                    }
                                    if (json_object_3.contains("artists"))//歌手
                                    {
                                        QJsonValue artists_value_tmp = json_object_3.value("artists");
                                        if(artists_value_tmp.isArray())
                                        {
                                            QJsonArray artists_array = artists_value_tmp.toArray();
                                            int artists_size=artists_array.size();
                                            for(int k=0;k<artists_size;k++)
                                            {
                                                QJsonValue artists_name=artists_array.at(k);
                                                if(artists_name.isObject())
                                                {
                                                    QJsonObject artists_name_object=artists_name.toObject();
                                                    if(artists_name_object.contains("name"))
                                                    {
                                                        QJsonValue artistsname = artists_name_object.take("name");
                                                        if (artistsname.isString())
                                                        {
                                                            if(k==0)
                                                            {
                                                                singername2 = artistsname.toString();
                                                            }
                                                            else
                                                            {
                                                                singername2 = singername2 + "/" +artistsname.toString();
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (json_object_3.contains("name"))//歌曲名
                                    {
                                        QJsonValue Album_ID_value = json_object_3.take("name");
                                        if (Album_ID_value.isString())
                                        {
                                            songname_original2 = Album_ID_value.toString();
                                        }
                                    }
                                    if (json_object_3.contains("duration"))//时长
                                    {
                                        QJsonValue AlbumID_value = json_object_3.take("duration").toInt();
                                        duration2 = AlbumID_value.toInt();
                                        duration2=duration2/1000;
                                    }
                                    if (json_object_3.contains("id"))//歌曲id
                                    {
                                        QJsonValue FileHash_value = json_object_3.take("id");
                                        if (!FileHash_value.isNull())
                                        {
                                            //用Vector保存每首歌曲的album_id
                                            music_id=FileHash_value.toInt();
                                        }
                                    }
                                    song _song;//定义一个歌曲结构体
                                    _song.album_name = album_name2;
                                    _song.singer = singername2;
                                    _song.songname = songname_original2;
                                    _song.duration2 = duration2;
                                    _song.music_id = music_id;
                                    song_List.push_back(_song);//保存歌曲信息到链表

                                    //                                    qDebug()<< id << endl;
                                    //构建歌曲播放链接
                                    QString play_url = QString("http://music.163.com/song/media/outer/url?id=%1.mp3").arg(music_id);
                                    playlist->addMedia(QUrl(play_url));//把歌曲加入到播放列表

                                    // 更新表格显示
                                    pModel->setHorizontalHeaderLabels(titles);
                                    QList<QStandardItem *> sti;
//                                    for(QList<song>::iterator iter = song_love.begin();iter!=song_love.end();iter++)
//                                    {
//                                        if(iter->songname == songname_original2)
//                                        {
//                                            love_index = 1;
//                                        }

//                                    }

                                    QFile filepath("D:/123/love.txt");
                                    if(filepath.open(QIODevice::ReadOnly | QIODevice::Text))
                                    {
                                        QTextStream read(&filepath);
                                        read.setCodec("UTF-8");  // 设置编码为UTF-8

                                        while(!read.atEnd())
                                        {
                                            QString Line = read.readLine();

                                            songList << Line;

                                        }
                                        filepath.close();
                                    }
                                    else
                                    {
                                        qDebug() << "文件打开错误_1" << endl;
                                    }
                                    filepath.close();
                                    QStringList::iterator iter = songList.begin();
                                    for(int i = 0;iter != songList.end();iter++,i++)
                                    {
                                        if(songList.at(i) == QString().number(music_id))
                                        {
                                            qDebug() << "----------------------------------" << endl;
                                           love_index = 1;
                                        }

                                    }

//                                    qDebug() << love_index << endl;
                                    if(love_index == 1)
                                    {
                                        sti<< new QStandardItem(songname_original2)<< new QStandardItem(singername2)
                                           << new QStandardItem(album_name2)<<new QStandardItem(QString().number(duration2))<< new QStandardItem("已收藏");
                                    }
                                    else
                                    {
                                        sti<< new QStandardItem(songname_original2)<< new QStandardItem(singername2)
                                           << new QStandardItem(album_name2)<<new QStandardItem(QString().number(duration2))<< new QStandardItem("未收藏");
                                    }

                                    love_index = 0;
                                    pModel->appendRow(sti);
                                    //                                    QDebug() << playli

                                }


                            }
                            ui->tableView->setColumnWidth(0,300);
                            ui->tableView->setColumnWidth(1,150);
                            ui->tableView->setColumnWidth(2,150);
                            ui->tableView->setColumnWidth(3,150);
                            ui->tableView->setColumnWidth(4,150);
                            ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);//用户不能修改单元格宽度
                            ui->tableView->verticalHeader()->setDefaultSectionSize(60);//设置行高
                            for(int i = 0 ; i < size ; i++)
                            {
                                for(int j = 0 ; j < 5 ; j++)
                                {
                                    pModel->item(i,j)->setTextAlignment(Qt::AlignCenter);
                                }
                            }
                            //                            //为每首歌获取歌词
                            //                            for (const song &s : song_List) {
                            //                                QString lrcUrl = QString("https://music.163.com/api/song/lyric?id=%1&lv=1&kv=1&tv=-1").arg(s.music_id);
                            //                                manage->get(QNetworkRequest(QUrl(lrcUrl)));
                            //                            }
                        }
                    }
                }
            }
        }
    }

}


music::~music()
{
    delete ui;
}


void music::on_tableView_clicked(const QModelIndex &index)
{
    if(index.column() != 4)//如果不是第四列就不要改变
    {

        return;
    }
    QVariant ret = pModel->data(index);//获得索引标识的模型数据
    QStandardItem * item = pModel->item(index.row(),index.column());
    delete item;//释放掉原有的选项
    //    以下代码要实际开发的时候要结合数据库的插入和删除操作
    if(ret == "未收藏")
    {
        pModel->setItem(index.row(),index.column(),new QStandardItem("已收藏"));
        song currentSong;
        currentSong.singer = currentSinger;
        currentSong.music_id = currentSongId;
        currentSong.songname = currentSongName;
        currentSong.duration2 = currentDuration2;
        currentSong.album_name = currentAlbum_name;
        song_love.push_back(currentSong);
        QFile filepath("D:/123/love.txt");
        if(filepath.open(QIODevice::Append | QIODevice::Text))
        {
            QTextStream write(&filepath);
            write.setCodec("UTF-8");
            write << currentSong.music_id << "\n";
            qDebug() << currentSong.music_id << endl;
            qDebug() << currentSongId << endl;
        }
        else
        {
            qDebug() << "文件打开错误" << endl;
        }

        filepath.close();


    }
    else if(ret == "已收藏")
    {
        pModel->setItem(index.row(),index.column(),new QStandardItem("未收藏"));
        QList<song>::iterator iter = song_love.begin();
        for(;iter != song_love.end();iter++)
        {
            if(iter->songname == currentSongName)
            {
                song_love.erase(iter);
                QFile filepath("D:/123/love.txt");
                if(filepath.open(QIODevice::ReadOnly | QIODevice::Text))
                {
                    QTextStream read(&filepath);
                    read.setCodec("UTF-8");  // 设置编码为UTF-8

                    while(!read.atEnd())
                    {
                        QString Line = read.readLine();
                        if(Line != currentSongId)
                        {
                            songList << Line;
                        }
                    }
                    filepath.close();
                    if (!filepath.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
                            qDebug() << "文件打开错误_2" << endl;
                            return;
                        }

                        QTextStream out(&filepath);
                        out.setCodec("UTF-8");
                        for (const QString& line : songList) {
                            out << line << "\n";
                        }
                        filepath.close();


                }
                else
                {
                    qDebug() << "文件打开错误_1" << endl;
                }
                filepath.close();


            }
        }
    }




}

void music::on_pushButton_clicked()
{

    if(player->state() == QMediaPlayer::PlayingState)
    {
        player->pause();
        ui->pushButton->setStyleSheet("border-image:url(:/播放 (1).png);border: 1px solid black;border-radius:20px;");
    }
    else
    {
        player->play();
        ui->pushButton->setStyleSheet("border-image:url(:/暂停.png);border: 1px solid black;border-radius:20px;");
    }
}

void music::on_pushButton_2_clicked()
{

    // 获取当前播放列表的歌曲数量
    int currentPlaylistSize = playlist->mediaCount();

    pModel->clear();
    pModel->setHorizontalHeaderLabels(titles);  // 重新设置表头标题



    QString key = ui->lineEdit->text();
    manage->get(QNetworkRequest(QUrl(QString("http://music.163.com/api/search/get/web?csrf_token=hlpretag=&hlposttag=&s=%1&type=1&offset=0&total=true&limit=50").arg(key))));

    ui->pushButton->setStyleSheet("border-image:url(:/播放 (1).png);border: 1px solid black;border-radius:20px;");
    // 在新的搜索开始时，记录下当前播放列表的起始索引
    newSearchStartIndex = currentPlaylistSize;
}




void music::getMusicLrc(QByteArray data)
{
    //    qDebug() << "JSON Data:" << QString(data);

    QString lrcText;
    QJsonParseError json_error;//JSON解析错误对象

    QJsonDocument parse_doucment = QJsonDocument::fromJson(data, &json_error);
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            QJsonObject lrcObject = parse_doucment.object();
            if(lrcObject.contains("lrc"))
            {
                QJsonValue lrcValue = lrcObject.value("lrc");
                if(lrcValue.isObject())
                {
                    QJsonObject lrcObject_2 = lrcValue.toObject();
                    if(lrcObject_2.contains("lyric"))
                    {
                        QJsonValue lrcValue_2 = lrcObject_2.value("lyric");
                        lrcText = lrcValue_2.toString();
                        //                        qDebug() << "Lyric Text:" << lrcText;


                        if (lrcText != "")
                        {	//将整个歌词给s

                            QString s = lrcText;
                            // s1 用列表的形式保存每一句歌词
                            QStringList s1 = s.split("\n");
                            qDebug() << "-------------------------------------------------------------" << endl;
                            for (int i = 0; i < s1.size(); ++i)
                            {
                                QString ss1 = s1.at(i);
                                // 判断歌词行是否包含时间戳
                                QRegExp ipRegExp = QRegExp("\\[(\\d+):(\\d+)(\\.\\d+)?\\](.*)");
                                if (ipRegExp.indexIn(ss1) != -1)
                                {
                                    // 提取时间戳的分钟、秒和毫秒部分
                                    QString minutes = ipRegExp.cap(1); // 分钟
                                    QString seconds = ipRegExp.cap(2); // 秒
                                    QString milliseconds = ipRegExp.cap(3); // 毫秒（可选）

                                    // 将时间转换为秒数（毫秒默认为0）
                                    int min = minutes.toInt();
                                    int sec = seconds.toInt();
                                    int ms = milliseconds.isEmpty() ? 0 : milliseconds.mid(1).toInt(); // 去掉点

                                    // 计算总秒数
                                    int totalMilliseconds = (min * 60 + sec) * 1000 + ms; // 总毫秒数
                                    int lrctime = totalMilliseconds / 1000; // 转换为秒

                                    // 提取歌词文本
                                    QString lrcstr = ipRegExp.cap(4);

                                    // 将时间戳和歌词存储到 lrcMap 中
                                    lrcMap.insert(lrctime, lrcstr);
                                    qDebug() << "时间戳:" << lrctime << "歌词:" << lrcstr;
                                }

                            }
                        }
                        else
                        {
                            //没有歌词;
                        }
                    }
                }


            }
            else
            {
                qDebug() << "JSON does not contain 'lyric' field";
            }
        }
        else
        {
            qDebug() << "JSON is not an object";
        }

    }


    qDebug() << lrcText << endl;


}

void music::music_lic()
{

}

void music::slot_positionChanged(qint64 position)
{
    //    qDebug()<<position<<endl;
    ui->horizontalSlider->setValue(position);
    ui->label->setText(QString("%1").arg(position/1000));

    // 获取当前播放歌曲的 ID
    currentIndex = playlist->currentIndex();
    if (currentIndex >= 0 && currentIndex < song_List.size()) {
        currentSongId = song_List[currentIndex].music_id;
        currentSongName = song_List[currentIndex].songname;
        currentSinger = song_List[currentIndex].singer;
        currentDuration2 = song_List[currentIndex].duration2;
        currentAlbum_name = song_List[currentIndex].album_name;
        //        qDebug() << "当前播放歌曲的 ID：" << currentSongId;
    }
}


void music::slot_durationChanged(qint64 duration)
{
    qDebug()<<"开始播放一首新歌，总时长为："<<duration<<endl;
    ui->horizontalSlider->setRange(0,duration);
    ui->label_2->setText(QString("%1").arg(duration/1000));
    ui->pushButton->setStyleSheet("border-image:url(:/暂停.png);border: 1px solid black;border-radius:20px;");
}


void music::on_tableView_doubleClicked(const QModelIndex &index)
{
    int actualPlaylistIndex = newSearchStartIndex + index.row();
    playlist->setCurrentIndex(actualPlaylistIndex);
    player->play();

    int key = currentSongId;
    manage->get(QNetworkRequest(QUrl(QString("https://music.163.com/api/song/lyric?id=%1&lv=1&kv=1&tv=-1").arg(QString().number(key)))));

    lrcMap.clear();
    ui->label_4->setText(QString("%1").arg(currentSongName));
}

void music::on_pushButton_3_clicked()
{
    close();
}

void music::mousePressEvent(QMouseEvent *event)
{
    // 当鼠标左键按下时，开始记录位置
    if(event->button() == Qt::LeftButton) {
        m_isDragging = true;
        m_startPoint = event->globalPos();  // 记录鼠标按下时的全局位置
        m_windowPoint = this->frameGeometry().topLeft();  // 记录窗口左上角的位置
    }
}

void music::mouseMoveEvent(QMouseEvent *event)
{
    // 如果正在拖拽窗口
    if(m_isDragging) {
        QPoint movePoint = event->globalPos() - m_startPoint;  // 计算移动的距离
        this->move(m_windowPoint + movePoint);  // 更新窗口位置
    }
}

void music::mouseReleaseEvent(QMouseEvent *event)
{
    // 当鼠标释放时，停止拖拽
    if(event->button() == Qt::LeftButton) {
        m_isDragging = false;
    }
}





void music::on_pushButton_4_clicked()
{
    this->hide();
    showMainWindow();
}
