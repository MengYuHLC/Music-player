#include "registerform.h"
#include "ui_registerform.h"

registerForm::registerForm(QWidget *parent, QTcpSocket *socket) :
    QMainWindow(parent),
    ui(new Ui::registerForm),
    clientSocket(socket)
{
    ui->setupUi(this);
    QFile file(":/form_style.qss");//构建一个QFILE对象
    file.open(QIODevice::ReadOnly);//打开构造函数中指定的文件


    QTextStream in(&file);//创建一个文本流，参数为打开的文件
    in.setCodec("UTF-8");//设置读取编码为GBK的文件
    QString qs = in.readAll();//读取所有的文件内容
    file.close();
    this->setStyleSheet(qs);
    this->setWindowFlag(Qt::FramelessWindowHint);//把主窗口边框去掉
    this->setAttribute(Qt::WA_TranslucentBackground);//把窗口设置为透明
    ui->pushButton_2->setStyleSheet("border-image: url(:/关闭 (2).png); border:7px solid black; border-radius: 16px; ");


}

registerForm::~registerForm()
{
    delete ui;
}
void registerForm::on_pushButton_2_clicked()
{
    close();
}



void registerForm::mousePressEvent(QMouseEvent *event)
{
    // 当鼠标左键按下时，开始记录位置
    if(event->button() == Qt::LeftButton) {
        m_isDragging = true;
        m_startPoint = event->globalPos();  // 记录鼠标按下时的全局位置
        m_windowPoint = this->frameGeometry().topLeft();  // 记录窗口左上角的位置
    }
}

void registerForm::mouseMoveEvent(QMouseEvent *event)
{
    // 如果正在拖拽窗口
    if(m_isDragging) {
        QPoint movePoint = event->globalPos() - m_startPoint;  // 计算移动的距离
        this->move(m_windowPoint + movePoint);  // 更新窗口位置
    }
}

void registerForm::mouseReleaseEvent(QMouseEvent *event)
{
    // 当鼠标释放时，停止拖拽
    if(event->button() == Qt::LeftButton) {
        m_isDragging = false;
    }
}

void registerForm::on_pushButton_clicked()
{
    qDebug() << "4444444444444444444444444"<<endl;
    QMSG msg;
    msg.type = 1;//注册
    QString str = ui->LineEdit->text();
    std::string str1 = str.toStdString();

    QString str_psw = ui->LineEdit_2->text();
    std::string str_psw1 = str_psw.toStdString();

    register_node rn(str1.c_str(),str_psw1.c_str());
    memcpy(msg.buf,&rn,sizeof (rn));

    if (clientSocket)
    {
        clientSocket->write((char *)&msg, sizeof(msg));
    }
    else
    {
        qDebug() << "客户端Socket未初始化";
    }
    qDebug() << "5555555555555555555555"<<endl;
}

void registerForm::on_pushButton_3_clicked()
{
    this->hide();
    back();
}
