#ifndef REGISTERFORM_H
#define REGISTERFORM_H

#include <QMainWindow>
#include <QDebug>
#include <QMouseEvent>
#include <QCryptographicHash>
#include <QTcpServer>
#include <QTcpSocket>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QPainter>
#include "comment.h"
namespace Ui {
class registerForm;
}

class registerForm : public QMainWindow
{
    Q_OBJECT

public:
    explicit registerForm(QWidget *parent = nullptr, QTcpSocket *socket = nullptr);
    ~registerForm();
private slots:
    void on_pushButton_2_clicked();
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();
signals:
    void back();
private:
    Ui::registerForm *ui;
    QList<QPoint> pointList;//用来存放点的LIST

    bool m_isDragging;     // 判断是否正在拖拽窗口
    QPoint m_startPoint;   // 鼠标按下时的坐标
    QPoint m_windowPoint;  // 鼠标按下时窗口左上角的坐标
    QTcpSocket *clientSocket;
};

#endif // REGISTERFORM_H
