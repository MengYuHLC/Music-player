#include "test.h"
#include "ui_test.h"

test::test(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::test)
{
    ui->setupUi(this);
    setupDrawer();
//    this->setWindowFlag(Qt::FramelessWindowHint);//把主窗口边框去掉
//    this->setAttribute(Qt::WA_TranslucentBackground);//把窗口设置为透明
}
void test::setupDrawer()
{
    // 创建 QtMaterialDrawer 实例
    QtMaterialDrawer *drawer = new QtMaterialDrawer(this);

    // 设置抽屉的宽度
    drawer->setDrawerWidth(250);

    // 设置点击外部区域时自动关闭抽屉
    drawer->setClickOutsideToClose(true);

    // 设置抽屉的布局
    QVBoxLayout *layout = new QVBoxLayout;
    drawer->setDrawerLayout(layout);

    // 向抽屉中添加控件
    QPushButton *button1 = new QPushButton("Button 1", drawer);
    QPushButton *button2 = new QPushButton("Button 2", drawer);
    layout->addWidget(button1);
    layout->addWidget(button2);

    // 将抽屉添加到主窗口布局中
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    setLayout(mainLayout);
    mainLayout->addWidget(drawer);

    // 设置一个按钮来打开抽屉
    QPushButton *openButton = new QPushButton("Open Drawer", this);
    mainLayout->addWidget(openButton);
    connect(openButton, &QPushButton::clicked, drawer, &QtMaterialDrawer::openDrawer);
}

test::~test()
{
    delete ui;
}
