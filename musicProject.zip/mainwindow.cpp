#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include "comment.h"
#include "sqliteoperator.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //-------------------------------------------------------服务器--------------------------------------------------

    server = new QTcpServer(this);
    bool success = server->listen(QHostAddress::Any,9000);//设置端口号与ip地址
    if (success) {
        qDebug() << "服务器成功启动，正在监听端口 9000";
    } else {
        qDebug() << "服务器启动失败";
    }
    connect(server,&QTcpServer::newConnection,this,&MainWindow::onConnection);//将信号与槽函数关联
    sqliteOP = new SqliteOperator;
    sqliteOP->openDb();
//    sqliteOP->normalExec("create table user(name varchar(128),password varchar(128))");
//    sqliteOP->closeDb();
}


void MainWindow::onConnection()
{
    clientSocket = server->nextPendingConnection();//返回当前连接的客户端
    connect(clientSocket,&QTcpSocket::readyRead,this,&MainWindow::onRead);
    connect(clientSocket,&QTcpSocket::disconnected,this,&MainWindow::disconnect);
}

void MainWindow::onRead()
{
    if (clientSocket) {
       QMSG msg;
       int len = clientSocket->read((char*)&msg,sizeof(msg));//读取反过来的所有数据
       qDebug()<<"一共收到"<<len<<"个字节";

       if(msg.type == 1)//注册
       {
           register_node * rn = (register_node*)msg.buf;

//            ui->textEdit->append(rn->name);
//            ui->textEdit->append(rn->password);
//            if(rn->sex == true)
//            {
//               ui->textEdit->append("男");
//            }
//            else
//            {
//                ui->textEdit->append("女");
//            }

           QString sql = QString("insert into user values('%1','%2')").arg(rn->name).arg(rn->password);
           sqliteOP->normalExec(sql);
       }
       else if(msg.type == 2)//登录
       {
           //这个是用注册结构体发来的登录信息
           register_node * rn = (register_node*)msg.buf;

           QSqlQuery sqlQuery;//这个结构体用来存放查询的结果
           sqliteOP->normalQuery(sqlQuery, QString("select * from user where name='%1' and password='%2'").arg(rn->name).arg(rn->password));
//            while(sqlQuery.next())
//            {
//                QString name = sqlQuery.value(0).toString();
//                QString password = sqlQuery.value(1).toString();
//                bool sex = sqlQuery.value(2).toBool();
//                qDebug()<<QString("id:%1    name:%2    age:%3").arg(name).arg(password).arg(sex);
//            }
           //n
           if(sqlQuery.next())
           {
               qDebug()<<"用户登录成功"<<endl;
               char buf[128] = "right";
               clientSocket->write(buf,128);
           }


       }


//       //给客户端回复GET
//       char buf[128] = "get";
//       clientSocket->write(buf,128);
    }

}

void MainWindow::disconnect()
{

}

MainWindow::~MainWindow()
{
    sqliteOP->closeDb();
    delete ui;
}



