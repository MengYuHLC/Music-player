#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QTcpServer>
#include <QTcpSocket>
#include <QMainWindow>
#include "sqliteoperator.h"



QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



private slots:
    void onConnection();
    void onRead();
    void disconnect();

private:
    Ui::MainWindow *ui;

    QTcpServer *server;
    QTcpSocket *clientSocket;
    SqliteOperator * sqliteOP;//用于和数据库建立连接


};
#endif // MAINWINDOW_H
